clear; close all; clc

%% Bioreactor - Nonlinear and Linear model comparison
% Model parameters
mu_max = 0.5;    % Max specific growth rate
Ks = 0.1;       % Half-saturation constant
Y = 0.4;         % Cell yield from substrate

% Influent
Df = 0.35;      % Dilution rate
Sf = 1.0;       % Feed substrate

% Initial conditions
X = 0.1;       % Initial condition for Biomass (X' = 0)
S = 0.1;       % Initial condition for Substrate (S' = 0)
x0=[X,S];

% Time range
trange=linspace(1,40,100);  
%% Non-linear mode

[t,xnl] = ode45(@(t,x)nonlinearbio(t,x,Df,Sf,mu_max,Ks,Y),trange,x0);

% Plot non-linear model
yyaxis left
plot(t,xnl(:,1),'LineWidth',1); hold on
ylabel('Biomass')
yyaxis right
plot(t,xnl(:,2),'LineWidth',1); hold on
ylabel('Substrate');
xlabel('Time [s]');
set(gca,'FontSize',18);

%% Find equilibrium point
xss = fsolve(@(x)nonlinearbio(t,x,Df,Sf,mu_max,Ks,Y),x0);

%% Linearization (Symbolic Toolbox)
%------------------system states------------%
% x1 = Biomass
% x2 = Submstrate
%------------------system inputs------------%
% u1 = input: D
% u2 = input: Sf
%------------------system outputs------------%
% y1 = x1
% y2= x2
% A,B,C linearized system matrices 
syms mu_max Ks Y x1 x2 u1 u2

mu=mu_max*x2/(Ks+x2);
f1=-u1*x1+mu*x1;
f2=u1*(u2-x2)-mu*x1/Y;

A_ss=jacobian([f1;f2],[x1 x2]); % Calculating Jacobian at steady state points (symbolic)
B_ss=jacobian([f1;f2],[u1 u2]);

%% Evaluate the jacobians
mu_max = 0.5;    % Max specific growth rate
Ks = 0.1;       % Half-saturation constant
Y = 0.4;        % Cell yield from substrate

u1 = 0.35;     % Steady-state influent cold water flow (cm^3/sec)
u2 = 1;          % Steady-state influent hot water flow (cm^3/sec)

x1 = xss(1);    % 
x2 = xss(2);    % 

A = eval(A_ss);   % Linearized A matrix at steady state point
B = eval(B_ss);   % Linearized B matrix at steady state point
C = eye(2);
D = zeros(2);

%% Linear model for the two-tank system with input [ |u| - uss] and output [ |x|-x2ss]:  
biolin = ss(A,B,C,D,'InputName',{'Df','Sf'},'OutputName',{'X','S'});
[y,t]=lsim(biolin,zeros(size(t,1),2),trange,x0-xss);

%% Plot comparison
y_nlin=xnl; y_lin=y+xss;

figure(2)
plot(t,y_nlin(:,1),t,y_lin(:,1),'LineWidth',1); 
set(gca,'FontSize',18);
legend('X_{NL}','X_{L}')
xlabel('Time [s]'); ylabel('Biomass')
axis tight
hold off

figure(3)
plot(t,y_nlin(:,2),t,y_lin(:,2),'LineWidth',1); 
set(gca,'FontSize',18);
legend('S_{NL}','S_{L}')
xlabel('Time [s]'); ylabel('Substrate')
axis tight
hold off


function dxdt=nonlinearbio(t,x,Df,Sf,mu_max,Ks,Y)

mu=mu_max*x(2)/(Ks+x(2));

dxdt(1,1)=-Df*x(1)+mu*x(1);
dxdt(2,1)=Df*(Sf-x(2))-mu*x(1)/Y;

end